<aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="."
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Principal</span></a></li>
                                   
                        <li class="list-divider"></li>
                         <li class="nav-small-cap"><span class="hide-menu">Cadastros</span></li>
                     
                        <li class="sidebar-item"> 
                            <a class="sidebar-link has-arrow" href="javascript:void(0)" aria-expanded="false">
                                <i data-feather="file-text" class="feather-icon"></i>
                                <span class="hide-menu">Usuários </span>
                            </a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="usuarios.php" class="sidebar-link"><span class="hide-menu"> Listar Usuários </span></a></li>
                                <li class="sidebar-item"><a href="add-usuario.php" class="sidebar-link"><span class="hide-menu"> Adicionar Usuário </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> 
                                        <a class="sidebar-link sidebar-link" href="newsletters.php" aria-expanded="false">
                                            <i class="fas fa-calendar-alt"></i>
                                            <span class="hide-menu">Newsletters</span>
                                        </a>
                                    </li>
                        <li class="list-divider"></li>
                         <li class="nav-small-cap"><span class="hide-menu">Configurações Site</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Banners </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="banners.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Banners
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-banner.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Banner
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                       <!--  <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Serviços </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="servicos.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar serviços
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-servico.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar serviço
                                        </span></a>
                                </li>
                            </ul>
                        </li> -->
                        <li class="sidebar-item"> 
                                        <a class="sidebar-link sidebar-link" href="textos.php" aria-expanded="false">
                                            <i class="fas fa-calendar-alt"></i>
                                            <span class="hide-menu">Textos</span>
                                        </a>
                                    </li>
                        <!-- <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Testemunhos </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="testemunhos.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Testemunhos
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-testemunho.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Testemunho
                                        </span></a>
                                </li>
                            </ul>
                        </li> -->
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Blog </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="blogs.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Blog
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-blog.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Blog
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                         <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Treinamentos </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="treinamentos.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Treinamento
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-treinamento.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Treinamento
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                         <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Soluções RH </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="solucoes.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Soluções RH
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-solucao.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Solução
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                       <!--  <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Produtos </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="produtos.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Produtos
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-produto.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Produto
                                        </span></a>
                                </li>
                            </ul>
                        </li> -->
                        <!-- <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Galeria </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="galerias.php" class="sidebar-link"><span
                                            class="hide-menu"> Listar Galeria
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="add-galeria.php" class="sidebar-link"><span
                                            class="hide-menu"> Adicionar Galeria
                                        </span></a>
                                </li>
                            </ul>
                        </li> -->
                       
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
                                    class="hide-menu">Configurações </span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="configuracoes.php" class="sidebar-link"><span
                                            class="hide-menu"> Configurações Gerais
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="metas-tags.php" class="sidebar-link"><span
                                            class="hide-menu"> Metas Tags
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Extra</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="login.php?acao=logout"
                                aria-expanded="false"><i data-feather="log-out" class="feather-icon"></i><span
                                    class="hide-menu">Logout</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>